import string
import CSV





file = "data.csv"
file__out = "data_out.csv"




print "CSV.py test program     Copyright (c) Laurence Tratt 1998 - 1999\n\n"

# Create a CSV instance

csv = CSV.CSV()

# Load up the file. We only have to give it the filename
# If you need to give it data already in memory, you need the "input" method

print "Loading CSV file '%s'..." % file
csv.load(file, 1)
print "Loaded..."

# Because our test file has field titles, print them out

print "\n\nField titles =", csv.fields__title

# Iterate over the entries

print "\n\nPrinting out entries:\n"
for entry in csv:
	print entry

# Iterate backwards over the entries, printing out the 1st field from each entry

print "\n\nPrinting out the first field from each entry whilst iterating backwards over the list:\n"
csv__reversed = csv
csv__reversed.reverse()
for entry in csv__reversed:
	print entry[0]

# Add an entry

print "\n\nAdding an entry to the end of the list..."
entry = CSV.Entry(["Dave", "01823 418289", "Taunton", 1.01010101])
print "The new entry is :", entry
csv.append(entry)
print "Added entry"

# Sort our list out

print "\n\nSorting list out into alphabetical order (sort by person name)..."
csv.sort(lambda a, b : cmp(a[0], b[0]))
print "Sorted"

# Print out some named fields. We'll do "Name" and "Address"

print "\n\nPrinting out two named fields (Name & Address) from each entry:\n"

for entry in csv:
	print entry["Name"], "lives in", entry["Address"]

# Add a column. Our new column is simply the "Silly number" rounded to the nearest whole number

csv.field__append(lambda a : `int(round(float(a["Silly number"])))`, "round(Silly number)") 

# Dump our CSV file in a readable format

print "\n\nPrinting CSV file to screen in a readable format:\n"
print csv

# Save the CSV data out

print
while 1:
	input = string.lower(raw_input("Would you like me to save out a CSV file of our altered data? I'll call it " + file__out + ". Y/N "))
	if input == "y":
		print "OK, saving file..."
		csv.save(file__out)
		print "Saved"
		break
	elif input == "n":
		print "OK, won't save file"
		break

print "\nThis test file has now completed"
